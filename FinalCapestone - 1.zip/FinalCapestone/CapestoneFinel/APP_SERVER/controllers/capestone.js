const request = require("request");
const apiOptions = {
  server: "http://localhost:3000"
};
const _renderHomePage = function(req, res, responseBody) {
  res.render("houselist", {
    title: "Home List",
    houses: responseBody
  });
};

const homeList = function(req, res) {
  const path = "/api/capestone";
  const requestOptions = {
    url: apiOptions.server + path,
    method: "GET",
    json: {}
  };

  request(requestOptions, (err, response, body) => {
    if (err) console.log(err);
    _renderHomePage(req, res, body);
  });
};
const _renderDetailsPage = function(req, res, responseBody) {
  res.render("home-info", {
    title: "Selected House",
    currentHouse: responseBody
  });
};
const HouseInfo = function(req, res) {
  const path = `/api/capestone/${req.params.houseid}`;
  const requestOptions = {
    url: apiOptions.server + path,
    method: "GET",
    json: {}
  };

  request(requestOptions, (err, response, body) => {
    _renderDetailsPage(req, res, body);
  });
};

const _renderCreatepage = function(req, res) {
  res.render("create-new-add", { title: "Create New Add" });
};

const addNewHouse = function(req, res) {
  _renderCreatepage(req, res);
};

const doAddNewHouse = function(req, res) {
  const path = "/api/capestone";
  const postdata = {
    housename: req.body.housename,
    type: req.body.type
  };

  const requestOptions = {
    url: apiOptions.server + path,
    method: "POST",
    json: postdata
  };

  request(requestOptions, (err, response, body) => {
    if (response.statusCode === 201) {
      res.redirect("/");
    }
  });
};
//calling the above function
module.exports = {
  homeList,
  HouseInfo,
  doAddNewHouse,
  addNewHouse
};
