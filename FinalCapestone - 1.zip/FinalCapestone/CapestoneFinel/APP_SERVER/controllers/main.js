const index = function(req, res) {
  res.render("index", { title: "Capestone Final" });
};

module.exports = {
  index
};
