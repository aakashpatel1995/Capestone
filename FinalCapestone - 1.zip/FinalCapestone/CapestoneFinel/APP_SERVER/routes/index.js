var express = require("express");
const ctrlMain = require("../controllers/main");
var router = express.Router();
const ctrlHouse = require("../controllers/capestone");

/* GET home page. */
router.get("/", ctrlHouse.homeList);
router.get("/houses/:houseid", ctrlHouse.HouseInfo);
router
  .route("/new")
  .get(ctrlHouse.addNewHouse)
  .post(ctrlHouse.doAddNewHouse);

module.exports = router;
