var express = require("express");
var router = express.Router();
const ctrlcapestone = require("../controllers/capestone"); // the main controllers file

//Defines location routes and maps them to controller functions
router.get("/houses", ctrlcapestone.getHouse);

router.post("/houses", ctrlcapestone.createHouse);
//
router.get("/houses/:houseid", ctrlcapestone.getSingleHouse);
router.put("/houses/:houseid", ctrlcapestone.updateHouse);
router.delete("/houses/:houseid", ctrlcapestone.deleteHouse);

module.exports = router;
