//create a connection
const mongoose = require("mongoose");

//Monitors for a successful connection through Mongoose
const dbURI =
  "mongodb+srv://aakash:aakash@cluster0-dswbf.mongodb.net/test?retryWrites=true&w=majority";
mongoose.connect(dbURI, { dbName: "houseDB", useNewUrlParser: true });

//Checks for a connection error
mongoose.connection.on("connected", () => {
  console.log(`Mongoose connected to ${dbURI}`);
});

mongoose.connection.on("error", err => {
  console.log("Mongoose connection error:", err);
});

mongoose.connection.on("disconnected", () => {
  console.log("Mongoose disconnected");
});

require("./capestone");
