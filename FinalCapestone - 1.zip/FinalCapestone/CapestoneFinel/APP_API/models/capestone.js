const mongoose = require("mongoose");

var houseSchema = new mongoose.Schema({
  housename: { type: String, required: true, minlength: 8 },
  type: { type: String, required: true }
});

var houseModel = mongoose.model("houses", houseSchema);

module.exports = houseModel;
