var mongoose = require("mongoose");
var houses = mongoose.model("houses");

const getHouse = function(req, res) {
  houses.find().exec(function(err, housedata) {
    //Gets a songid from the URL parameters, and gives it to the findById method
    if (err) {
      res
        .status(404) //Defines callback to accept possible parameters
        .json(err);
      return;
    }
    res
      .status(200) //Sends the document found parameters as a JSON response with an HTTP status of 200
      .json(housedata);
  });
};

const createHouse = function(req, res) {
  houses.create(
    {
      housename: req.body.housename, // //create paths with values for the submitted form
      type: req.body.type
    },
    (err, housedata) => {
      if (err) {
        res.status(400).json(err);
      } else {
        res.status(201).json(housedata);
      }
    }
  );
};

const getSingleHouse = function(req, res) {
  houses.findById(req.params.houseid).exec((err, house) => {
    if (!house) {
      return res.status(404).json({
        message: "House not found"
      });
    } else if (err) {
      return res.status(404).json(err);
    }
    res.status(200).json(house);
  });
};

const updateHouse = function(req, res) {
  if (!req.params.houseid) {
    res.status(404).json({
      message: "Not found, song id is required"
    });
    return;
  }
  house.findById(req.params.houseid).exec((err, housedata) => {
    if (!housedata) {
      res.status(404).json({
        message: "House id not found."
      });
      return;
    } else if (err) {
      res.status(400).json(err);
      return;
    }
    housedata.housename = req.body.housename; //Updates paths with values from the submitted form
    housedata.type = req.body.type;
    housedata.save((err, housedata) => {
      if (err) {
        res.status(404).json(err);
      } else {
        res.status(200).json(housedata);
      }
    });
  });
};

const deleteHouse = function(req, res) {
  const houseid = req.params.houseid; //Calls findByIdAndRemove method, passing in houseid

  if (houseid) {
    houses.findByIdAndRemove(houseid).exec((err, housedata) => {
      //Executes the method
      if (err) {
        res.status(404).json(err);
      } else {
        res.status(204).json({ message: "Document deleted" });
      }
    });
  } else {
    res.status(404).json({ message: "no House id" });
  }
};
module.exports = {
  getHouse,
  createHouse,
  getSingleHouse,
  updateHouse,
  deleteHouse
};
